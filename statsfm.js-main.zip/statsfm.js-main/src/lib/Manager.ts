import { HttpManager } from './http/HttpManager';

export default class Manager {
  constructor(protected http: HttpManager) {}
}
