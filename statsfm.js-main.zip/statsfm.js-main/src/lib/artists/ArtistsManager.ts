import { ItemResponse, ItemsResponse } from '../../interfaces';
import * as statsfm from '../../interfaces/statsfm';
import Manager from '../Manager';

export default class ArtistsManager extends Manager {
  /**
   * @description Get a artist by ID.
   * @param {number} id The ID of the artist.
   * @returns {Promise<Artist>} Returns a promise with a single {@link Artist}.
   */
  async get(id: number): Promise<statsfm.v1.Artist> {
    const res = await this.http.get<ItemResponse<statsfm.v1.Artist>>(`/artists/${id}`);

    return res.item;
  }

  /**
   * @description Get a list of artists by IDs.
   * @param {number} ids The IDs of the track.
   * @returns {Promise<Artist[]>} Returns a promise with a {@link Artist}s.
   */
  async list(ids: number[]): Promise<statsfm.v1.Artist[]> {
    const res = await this.http.get<ItemsResponse<statsfm.v1.Artist[]>>(`/artists/list`, {
      query: {
        ids: ids.join(',')
      }
    });

    return res.items;
  }

  async getSpotify(id: string): Promise<statsfm.v1.Artist> {
    const res = await this.http.get<ItemResponse<statsfm.v1.Artist>>(`/artists/${id}`, {
      query: {
        type: 'spotify'
      }
    });

    return res.item;
  }

  async listSpotify(ids: string[]): Promise<statsfm.v1.Artist[]> {
    const res = await this.http.get<ItemsResponse<statsfm.v1.Artist[]>>(`/artists/list`, {
      query: {
        ids: ids.join(','),
        type: 'spotify'
      }
    });

    return res.items;
  }

  /**
   * @description Get a list of tracks by the artist ID.
   * @param {number} id The IDs of the artist.
   * @returns {Promise<Track[]>} Returns a promise with a {@link Track[]}s.
   */
  async tracks(id: number): Promise<statsfm.v1.Track[]> {
    const res = await this.http.get<ItemsResponse<statsfm.v1.Track[]>>(`/artists/${id}/tracks`);

    return res.items;
  }

  async topTracks(id: number): Promise<statsfm.v1.Track[]> {
    const res = await this.http.get<ItemsResponse<statsfm.v1.Track[]>>(`/artists/${id}/tracks/top`);

    return res.items;
  }

  async albums(id: number): Promise<statsfm.v1.Album[]> {
    const res = await this.http.get<ItemsResponse<statsfm.v1.Album[]>>(`/artists/${id}/albums`);

    return res.items;
  }

  async topAlbums(id: number): Promise<statsfm.v1.Album[]> {
    const res = await this.http.get<ItemsResponse<statsfm.v1.Album[]>>(`/artists/${id}/albums/top`);

    return res.items;
  }

  async related(id: number): Promise<statsfm.v1.Artist[]> {
    const res = await this.http.get<ItemsResponse<statsfm.v1.Artist[]>>(`/artists/${id}/related`);

    return res.items;
  }

  async topListeners(id: number, friendsOnly = false): Promise<statsfm.TopUser[]> {
    const res = await this.http.get<ItemsResponse<statsfm.TopUser[]>>(
      `/artists/${id}/top/listeners`,
      {
        authRequired: true,
        query: friendsOnly === false ? {} : { friends: friendsOnly } // for caching
      }
    );

    return res.items;
  }
}
