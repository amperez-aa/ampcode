import { UserPublic } from './user';

export interface Soulmate {
  score: number;
  user: UserPublic;
}
