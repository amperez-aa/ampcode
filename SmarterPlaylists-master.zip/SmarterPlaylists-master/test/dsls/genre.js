{
    "main": "EchoNestGenreRadio-1",
    "components": {
        "EchoNestGenreRadio-1": {
            "_type": "EchoNestGenreRadio",
            "genre": "pop"
        }
    }
}
