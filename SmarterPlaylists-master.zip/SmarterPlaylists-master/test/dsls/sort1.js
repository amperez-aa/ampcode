{
    "components": {
        "yfc" : { 
            "_type": "SpotifyPlaylist",
            "name" : "Your Favorite Coffeehouse"
        },

        "sorter": {
            "_type":"Sorter",
            "attr": "title",
            "source": "yfc"
        }
    },
    "main": "sorter"
}
