
{
    "components": {
        "weezer" : { 
            "_type": "ArtistTopTracks",
            "name" : "Weezer"
        }
    },
    "main": "weezer"
}
