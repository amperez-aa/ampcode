{
    "components": {
        "yfc" : { 
            "_type": "SpotifyPlaylist",
            "name" : "Your Favorite Coffeehouse"
        },

        "tp" : { 
            "_type": "SpotifyPlaylist",
            "name" : "Teen Party"
        },

        "alt" : {
            "_type": "Alternate",
            "source_list" : ["yfc", "yfc", "yfc", "tp"]
        }
    },
    "main": "alt"
}
