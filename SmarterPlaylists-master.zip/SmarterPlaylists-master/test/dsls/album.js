{
    "components": {
        "weezer" : { 
            "_type": "AlbumSource",
            "title" : "Weezer",
            "artist" : "Weezer"
        }
    },
    "main": "weezer"
}
