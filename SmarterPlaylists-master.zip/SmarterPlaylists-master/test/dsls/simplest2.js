{
    "components": {
        "tp" : { 
            "_type": "SpotifyPlaylist",
            "name" : "Teen Party"
        }
    },
    "main": "tp"
}
