<p align="center">
  <a href="https://stats.fm">
    <picture width="572">
      <source media="(prefers-color-scheme: dark)" srcset="https://stats.fm/images/banner_transparent.png">
      <img src="https://stats.fm/images/banner.png" width="572">
    </picture>
  </a>
</p>

<p align="center">
  Repository for the stats.fm dart package.
</p>